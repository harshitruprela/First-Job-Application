package com.severus.companyms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanymsApplicationTests {

	@Test
	void contextLoads() {
	}

}
